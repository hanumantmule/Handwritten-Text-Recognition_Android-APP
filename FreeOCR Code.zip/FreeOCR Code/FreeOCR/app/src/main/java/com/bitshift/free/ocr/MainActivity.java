package com.bitshift.free.ocr;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import androidx.annotation.NonNull;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.core.content.FileProvider;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.animation.PathInterpolatorCompat;
import com.getkeepsafe.taptargetview.TapTarget;
import com.getkeepsafe.taptargetview.TapTargetSequence;

import android.text.format.DateFormat;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mlkit.helpers.MyHelper;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.common.FirebaseMLException;
import com.google.firebase.ml.common.modeldownload.FirebaseModelDownloadConditions;
import com.google.firebase.ml.common.modeldownload.FirebaseModelManager;
import com.google.firebase.ml.custom.FirebaseCustomLocalModel;
import com.google.firebase.ml.custom.FirebaseCustomRemoteModel;
import com.google.firebase.ml.custom.FirebaseModelDataType;
import com.google.firebase.ml.custom.FirebaseModelInputOutputOptions;
import com.google.firebase.ml.custom.FirebaseModelInputs;
import com.google.firebase.ml.custom.FirebaseModelInterpreter;
import com.google.firebase.ml.custom.FirebaseModelInterpreterOptions;
import com.google.firebase.ml.custom.FirebaseModelOutputs;

import com.bitshift.free.ocr.R;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import es.dmoral.toasty.Toasty;

import static com.bitshift.free.ocr.splash.transparentStatusAndNavigation;


public class MainActivity extends AppCompatActivity {

   
    private static final int MAX_DIMENSION = 1200;

	private static final int RESULTS_TO_SHOW = 3;
    private static final int DIM_BATCH_SIZE = 1;
    private static final int DIM_PIXEL_SIZE = 3;
 
	
    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int GALLERY_PERMISSIONS_REQUEST = 0;
    private static final int GALLERY_IMAGE_REQUEST = 1;
    public static final int CAMERA_PERMISSIONS_REQUEST = 2;
    public static final int CAMERA_IMAGE_REQUEST = 3;
    private static final int CREATE_FILE = 40;
	
	// Name of the model file hosted with Firebase
    private static final String HOSTED_MODEL_NAME = "FreeOCR";
    private static final String LOCAL_MODEL_ASSET = "output_model.tflite";
    private FirebaseCustomLocalModel localModel;
    private FirebaseCustomRemoteModel remoteModel;
	private FirebaseModelInterpreter mInterpreter;

    // Data configuration of input & output data of model.
    private FirebaseModelInputOutputOptions mDataOptions;
	
    Button save;
    private TextView mImageDetails;
    private ImageView mMainImage;
    TextView imageDetail;
    FloatingActionButton fab;
    static String scanned_text="";
    //to get user session data
    private UserSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        transparentStatusAndNavigation(this);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        fab = findViewById(R.id.fab);
        //animFab();
        fab.setFocusable(true);
        fab.setFocusableInTouchMode(true);///add this line
        fab.requestFocus();
        fab.setOnClickListener(view -> {

            final CharSequence[] items = {getString(R.string.from_library), getString(R.string.from_camera), getString(R.string.cancel)};
            androidx.appcompat.app.AlertDialog.Builder builder = new androidx.appcompat.app.AlertDialog.Builder(this);
            builder.setTitle("Add Photo!");
            builder.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int item) {
                    if (items[item].equals(getString(R.string.from_library))) {
                        startGalleryChooser();
                    } else if (items[item].equals(getString(R.string.from_camera))) {
                        startCamera();
                    } else if (items[item].equals(getString(R.string.cancel))) {
                        dialog.dismiss();
                    }
                }
            });
            builder.show();


        });

        mImageDetails = findViewById(R.id.image_details);
        mMainImage = findViewById(R.id.main_image);
        save=(Button)findViewById(R.id.btn_save);

        session = new UserSession(this);
        if (session.getFirstTime()) {
            //tap target view
            save.setVisibility(View.VISIBLE);
            tapview();
            //session.setFirstTime(false);
        }
    }


    private void tapview() {

        new TapTargetSequence(this)
                .targets(
                        TapTarget.forView(findViewById(R.id.fab), "Select Image", "Browse or capture Image from here !")
                                .targetCircleColor(R.color.colorAccent)
                                .titleTextColor(R.color.red)
                                .titleTextSize(25)
                                .descriptionTextSize(15)
                                .descriptionTextColor(R.color.gen_black)
                                .drawShadow(true)                   // Whether to draw a drop shadow or not
                                .cancelable(false)                  // Whether tapping outside the outer circle dismisses the view
                                .tintTarget(true)
                                .transparentTarget(true)
                                .outerCircleColor(R.color.skyblue),
                        TapTarget.forView(findViewById(R.id.btn_save), "Save", "Save the scanned text into file !")
                                .targetCircleColor(R.color.colorAccent)
                                .titleTextColor(R.color.pink)
                                .titleTextSize(25)
                                .descriptionTextSize(15)
                                .descriptionTextColor(R.color.gen_black)
                                .drawShadow(true)                   // Whether to draw a drop shadow or not
                                .cancelable(false)                  // Whether tapping outside the outer circle dismisses the view
                                .tintTarget(true)
                                .transparentTarget(true)
                                .outerCircleColor(R.color.light_green))
                .listener(new TapTargetSequence.Listener() {
                    // This listener will tell us when interesting(tm) events happen in regards
                    // to the sequence
                    @Override
                    public void onSequenceFinish() {
                        session.setFirstTime(false);
                       Toasty.success(MainActivity.this, " You are ready to go !", Toast.LENGTH_SHORT).show();
                        save.setVisibility(View.INVISIBLE);
                    }

                    @Override
                    public void onSequenceStep(TapTarget lastTarget, boolean targetClicked) {

                    }

                    @Override
                    public void onSequenceCanceled(TapTarget lastTarget) {
                        // Boo
                        //session.setFirstTime(true);
                        //save.setVisibility(View.INVISIBLE);
                    }
                }).start();

    }


    public void startGalleryChooser() {
        if (PermissionUtils.requestPermission(this, GALLERY_PERMISSIONS_REQUEST, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent, "Select a photo"),
                    GALLERY_IMAGE_REQUEST);
        }
    }

    public void startCamera() {
        if (PermissionUtils.requestPermission(
                this,
                CAMERA_PERMISSIONS_REQUEST,
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA)) {
            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            Uri photoUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", getCameraFile());
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, CAMERA_IMAGE_REQUEST);
        }
    }

    public File getCameraFile() {
        File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        return new File(dir, FILE_NAME);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            uploadImage(data.getData());
        } else if (requestCode == CAMERA_IMAGE_REQUEST && resultCode == RESULT_OK) {
            Uri photoUri = FileProvider.getUriForFile(this, getApplicationContext().getPackageName() + ".provider", getCameraFile());
            uploadImage(photoUri);
        }

        if (requestCode == CREATE_FILE &&  resultCode == Activity.RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();
                try{
                    ParcelFileDescriptor pfd =
                            this.getContentResolver().
                                    openFileDescriptor(uri, "w");

                    FileOutputStream fileOutputStream =
                            new FileOutputStream(
                                    pfd.getFileDescriptor());

                    String textContent =scanned_text.toString();
                    //System.out.println("Hanumant file data: "+textContent);
                    fileOutputStream.write(textContent.getBytes());

                    fileOutputStream.close();
                    pfd.close();
                    Toast.makeText(getApplicationContext(), "Document successfully created", Toast.LENGTH_SHORT).show();

                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Document not written", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Document not written", Toast.LENGTH_SHORT).show();

                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(getApplicationContext(), "Document not written", Toast.LENGTH_SHORT).show();
            }
        }
    }


    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case CAMERA_PERMISSIONS_REQUEST:
                if (PermissionUtils.permissionGranted(requestCode, CAMERA_PERMISSIONS_REQUEST, grantResults)) {
                    startCamera();
                }
                break;
            case GALLERY_PERMISSIONS_REQUEST:
                if (PermissionUtils.permissionGranted(requestCode, GALLERY_PERMISSIONS_REQUEST, grantResults)) {
                    startGalleryChooser();
                }
                break;
        }
    }

    public void uploadImage(Uri uri) {
        if (uri != null) {
            try {
                // scale the image to save on bandwidth
                Bitmap bitmap =
                        scaleBitmapDown(
                                MediaStore.Images.Media.getBitmap(getContentResolver(), uri),
                                MAX_DIMENSION);

                runModelInference(bitmap);
                mMainImage.setImageBitmap(bitmap);

            } catch (IOException e) {
                Log.d(TAG, "Image picking failed because " + e.getMessage());
                Toast.makeText(this, R.string.image_picker_error, Toast.LENGTH_LONG).show();
            }
        } else {
            Log.d(TAG, "Image picker gave us a null image.");
            Toast.makeText(this, R.string.image_picker_error, Toast.LENGTH_LONG).show();
        }
    }


	private void runModelInference(Bitmap bitmap) {
		try {
            mDataOptions = new FirebaseModelInputOutputOptions.Builder()
                    .setInputFormat(0, FirebaseModelDataType.BYTE, inputDims)
                    .setOutputFormat(0, FirebaseModelDataType.BYTE, outputDims)
                    .build();

            localModel = new FirebaseCustomLocalModel.Builder().setAssetFilePath(LOCAL_MODEL_ASSET).build();
            remoteModel = new FirebaseCustomRemoteModel.Builder(HOSTED_MODEL_NAME).build();

            FirebaseModelDownloadConditions.Builder conditionsBuilder = new FirebaseModelDownloadConditions.Builder().requireWifi();

			if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
				// Enable advanced conditions on Android Nougat and newer.
				conditionsBuilder = conditionsBuilder.requireCharging().requireDeviceIdle();
			}

            FirebaseModelDownloadConditions conditions = conditionsBuilder.build();
            FirebaseModelManager.getInstance().download(remoteModel, conditions).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    //Toast.makeText(getApplicationContext(), "Remote model is ready", Toast.LENGTH_LONG).show();
                }
            });

            FirebaseModelManager.getInstance().isModelDownloaded(remoteModel).addOnSuccessListener(new OnSuccessListener<Boolean>() {
                @Override
                public void onSuccess(Boolean isDownloaded) {
                    FirebaseModelInterpreterOptions options;
                    if (isDownloaded) {
                        options = new FirebaseModelInterpreterOptions.Builder(remoteModel).build();
                    } else {
                        options = new FirebaseModelInterpreterOptions.Builder(localModel).build();
                    }
                    try {
                        mInterpreter = FirebaseModelInterpreter.getInstance(options);
                    } catch (FirebaseMLException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (FirebaseMLException e) {
            mTextView.setText(R.string.error_setup_model);
            e.printStackTrace();
        }
		
        if (mInterpreter == null) {
            mTextView.setText(R.string.error_image_init);
            return;
        }
        ByteBuffer imgData = convertBitmapToByteBuffer(bitmap);

			try {
				FirebaseModelInputs inputs = new FirebaseModelInputs.Builder().add(imgData).build();
				mInterpreter.run(inputs, mDataOptions).addOnFailureListener(new OnFailureListener() {
					@Override
					public void onFailure(@NonNull Exception e) {
						e.printStackTrace();
						
					}
				}).continueWith(new Continuation<FirebaseModelOutputs, String>() {
					@Override
						public void onSuccess(FirebaseModelOutputs result) {
					  
						try {
											
							MainActivity activity = mActivityWeakReference.get();
							if (activity != null && !activity.isFinishing()) {
								imageDetail = activity.findViewById(R.id.image_details);
								imageDetail.setText(result);
							if(scanned_text != "")
								save.setVisibility(View.VISIBLE);

								save.setOnClickListener(new View.OnClickListener() {
								@Override
								public void onClick(View view) {


									String h = DateFormat.format("MM-dd-yyyyy-h-mmssaa", System.currentTimeMillis()).toString();
									// this will create a new name everytime and unique

									Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
									intent.addCategory(Intent.CATEGORY_OPENABLE);
									intent.setType("text/plain");
									intent.putExtra(Intent.EXTRA_TITLE, "freeocr.txt");

									startActivityForResult(intent, CREATE_FILE);
								}
								});
				
						} 
						catch (IOException e) {
								Log.d(TAG, "failed to make API request because of other IOException " +
								e.getMessage());
						}
					}
				});
				} 
			
			}
			catch (FirebaseMLException e) {
				e.printStackTrace();    
			}
    }

    private Bitmap scaleBitmapDown(Bitmap bitmap, int maxDimension) {

        int originalWidth = bitmap.getWidth();
        int originalHeight = bitmap.getHeight();
        int resizedWidth = maxDimension;
        int resizedHeight = maxDimension;

        if (originalHeight > originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = (int) (resizedHeight * (float) originalWidth / (float) originalHeight);
        } else if (originalWidth > originalHeight) {
            resizedWidth = maxDimension;
            resizedHeight = (int) (resizedWidth * (float) originalHeight / (float) originalWidth);
        } else if (originalHeight == originalWidth) {
            resizedHeight = maxDimension;
            resizedWidth = maxDimension;
        }
        return Bitmap.createScaledBitmap(bitmap, resizedWidth, resizedHeight, false);
    }

    private static String convertResponseToString(BatchAnnotateImagesResponse response) {
        StringBuilder message = new StringBuilder("I found these things:\n\n");

        TextAnnotation labels = response.getResponses().get(0).getFullTextAnnotation();

        if(labels != null) {
            message.append(labels.getText());
            message.append("\n\n");
        }
        else
            message.append("Sorry. FreeOCR could not detect any text from the image. Please try again.");

        if(labels != null)
            scanned_text=labels.getText().toString();

        return message.toString();

    }
	
	
    private synchronized ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer imgData = ByteBuffer.allocateDirect(DIM_BATCH_SIZE * DIM_IMG_SIZE_X * DIM_IMG_SIZE_Y * DIM_PIXEL_SIZE);
        imgData.order(ByteOrder.nativeOrder());
        Bitmap scaledBitmap = Bitmap.createScaledBitmap(bitmap, DIM_IMG_SIZE_X, DIM_IMG_SIZE_Y, true);
        imgData.rewind();
        scaledBitmap.getPixels(intValues, 0, scaledBitmap.getWidth(), 0, 0, scaledBitmap.getWidth(), scaledBitmap.getHeight());
        // Convert the image to int points.
        int pixel = 0;
        for (int i = 0; i < DIM_IMG_SIZE_X; ++i) {
            for (int j = 0; j < DIM_IMG_SIZE_Y; ++j) {
                final int val = intValues[pixel++];
                imgData.put((byte) ((val >> 16) & 0xFF));
                imgData.put((byte) ((val >> 8) & 0xFF));
                imgData.put((byte) (val & 0xFF));
            }
        }
        return imgData;
    }

}

